package profile;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.time.Duration;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TCforgotpass {

    public void forget()

    {
        //forget passward
        new WebDriverWait(class2.driver, Duration.ofSeconds(20)).until(ExpectedConditions.elementToBeClickable(By.className("forgot-password"))).click();
        try {
            Thread.sleep(2000);
        }

        catch(InterruptedException e){System.out.println(e);}
        //to perform Scroll on application using Selenium

        WebElement t = class2.driver.findElement(By.xpath("//*[text()='البريد الإلكترونى']"));
// Javascript executor
        ((JavascriptExecutor) class2.driver).executeScript("arguments[0].scrollIntoView(true);", t);
        try {
            Thread.sleep(2000);
        }

        catch(InterruptedException e){System.out.println(e);}


        class2.driver.findElement(By.id("userName")).sendKeys("sqa3@mailinator.com");
        try {
            Thread.sleep(2000);
        }

        catch(InterruptedException e){System.out.println(e);}

        class2.driver.findElement(By.id("submitButton")).click();

        try {
            Thread.sleep(2000);
        }

        catch(InterruptedException e){System.out.println(e);}


//        //to perform Scroll on application using Selenium

        WebElement txt = class2.driver.findElement(By.xpath("//*[text()='يرجى تفقد بريدك الالكتروني']"));
// Javascript executor
        ((JavascriptExecutor) class2.driver).executeScript("arguments[0].scrollIntoView(true);", txt);
        try {
            Thread.sleep(2000);
        }

        catch(InterruptedException e){System.out.println(e);}

        class2.driver.findElement(By.xpath("/html/body/div[5]/div[4]/div/div[2]/div[3]/div/div/div/div/table/tbody/tr/td/div[4]/input")).click();
    }
}
