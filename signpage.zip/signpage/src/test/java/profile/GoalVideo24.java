package profile;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import static profile.class2.driver;

public class GoalVideo24 {

        public void MgoalVideo(){
            JavascriptExecutor js = (JavascriptExecutor) driver;
            try {
                Thread.sleep(3000);
                WebElement h = driver.findElement(By.xpath("//*[text()='شاهد اهداف المباريات']"));
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", h);
                System.out.println("Text Found");
                Thread.sleep(2000);
            }
            catch (Exception exp) {
                System.out.println("Text Not Found");
            }
        try {
            Thread.sleep(2000);
            driver.findElement(By.xpath("//*[@id=\"tabbed-football-list-plugin\"]/div[6]/a")).click();
            System.out.println("Link opens");
            Thread.sleep(7000);
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            Thread.sleep(2000);
            driver.get("https://akhbaar24.argaam.com/");            Thread.sleep(2000);

        }
        catch (Exception exp) {
            System.out.println("Link not Open");
        }
            try {
                Thread.sleep(2000);
                driver.findElement(By.xpath("//a[@href='/video24/1']")).click();
                System.out.println("Opening Video24");
                Thread.sleep(8000);
                js.executeScript("window.scrollBy(0,150)", "");
                js.executeScript("window.scrollBy(0,150)", "");
                js.executeScript("window.scrollBy(0,150)", "");
            } catch (Exception exp) {
                System.out.println("Link not Open");
            }
            try {
                Thread.sleep(2000);
                driver.get("https://akhbaar24.argaam.com/");
                System.out.println("Going back to Home Page");
                Thread.sleep(6000);
            }catch (Exception exp) {
                System.out.println("Link not Open");
            }
        }


    }
