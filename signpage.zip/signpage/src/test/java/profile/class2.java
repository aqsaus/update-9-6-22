package profile;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import java.time.Duration;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class class2 {

    public static WebDriver driver;


    public static void main (String[] arg) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\aqsa\\Downloads\\Compressed\\chromedriver_win32\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        String baseUrl = "https://akhbaar24.argaam.com/";
        String expectedTitle = "اخبار 24 | اخبار السعودية على مدار 24 ساعة";
        String actualTitle ;
        driver.get(baseUrl);
        // get the actual value of the title
        actualTitle = driver.getTitle();
       System.out.println(actualTitle);

        if (actualTitle.contentEquals(expectedTitle)){
            System.out.println("Test Passed!home page tittle matched");
        } else {
            System.out.println("Test Failed home page tittle didn't matched");
        }

        Thread.sleep(3000);

        new WebDriverWait(driver, Duration.ofSeconds(20)).until(ExpectedConditions.elementToBeClickable(By.id("akhbaarPolicyAccpetButton"))).click();
        new WebDriverWait(driver, Duration.ofSeconds(20)).until(ExpectedConditions.elementToBeClickable(By.id("LoginInfoDiv"))).click();
        Thread.sleep(3000);
        intialtest a = new intialtest();
        a.sigin();
        a.profileedit();
//
//        Thread.sleep(2000);
//
//        Weather wthr = new Weather();
//        wthr.WeatherWidget();
//        Thread.sleep(2000);
////
//        MatchWidget MatchW = new MatchWidget();
//        MatchW.matchtab();
//
//        Thread.sleep(3000);
////
//        ComtRead mcr = new ComtRead();
//        mcr.readCmt();
//
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//        js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
//        System.out.println("Scrolling Down");
//        Thread.sleep(3000);
//        js.executeScript("window.scrollBy(0,-document.body.scrollHeight)");
//        System.out.println("Scrolling Up");
//
//        Thread.sleep(3000);
//////
////        GoalVideo24 mgv = new GoalVideo24();
////        mgv.MgoalVideo();
//
////
//
//        Thread.sleep(3000);
//        ArticleDetail artopn = new ArticleDetail();
//        artopn.articleopen();
//
//        Thread.sleep(3000);
//        sport24 sprt = new sport24();
//        sprt.sport();
//
//        video24 v = new video24();
//        v.video();
//
//        photo24 p = new photo24();
//        p.photo();
//
//        arab ar = new arab();
//        ar.arab24();
//
//        accident ac = new accident();
//        ac.accident24();
//
//        mix m = new mix();
//        m.mix24();
//
//        health h = new health();
//        h.health24();
//
//        technique tech = new technique();
//        tech.techniques24();
//
//        tourism to = new tourism();
//        to.tourism24();
//
//        car car = new car();
//        car.car24();
//
//        entertainment e = new entertainment();
//        e.entertainment24();





     // a.signout();






    }
    }
