package profile;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import static profile.class2.driver;

public class MatchWidget {
    public void matchtab(){

        JavascriptExecutor js = (JavascriptExecutor) driver;
        try {
            Thread.sleep(1000);
            WebElement l = driver.findElement(By.xpath("//*[text()='نتائج سابقة']"));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", l);
            driver.findElement(By.xpath(" //*[@id=\"matchOrderTab_tabbedFootballList\"]")).click();
            System.out.println("Previous Matched Tab Switches");
        }
        catch (Exception exp) {
            System.out.println("Previous Matched Tab not Switches");
        }
        try {
            Thread.sleep(3000);
            driver.findElement(By.xpath(" //*[@id=\"matchTab_tabbedFootballList\"]")).click();
            System.out.println("Today Matches Tab Switches");
            Thread.sleep(3000);
        }
        catch (Exception exp) {
            System.out.println("Today Matched Tab not Switches");
        }
        try {
            Thread.sleep(3000);
            driver.findElement(By.xpath(" //*[@id=\"matchResultTab_tabbedFootballList\"]")).click();
            System.out.println("Upcoming Matches Tab Switches");
            Thread.sleep(3000);
        }
        catch (Exception exp) {
            System.out.println("Today Matched Tab not Switches");
        }
    }
}
