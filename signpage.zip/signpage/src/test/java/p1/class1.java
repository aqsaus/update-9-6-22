package p1;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.time.Duration;
import java.util.ArrayList;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class class1 {

    public static void main (String[] arg) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\aqsa\\Downloads\\Compressed\\chromedriver_win32\\chromedriver.exe");

        //aurgments options
//        chromeOptions.addArguments("no-sandbox");
//        chromeOptions.addArguments("--test-type");
//        chromeOptions.addArguments("disable-infobars");
//        chromeOptions.addArguments("disable-extensions");
//drivers
        WebDriver driver = new ChromeDriver();
        JavascriptExecutor j = (JavascriptExecutor) driver;
        driver.manage().window().maximize();
        driver.get("https://akhbaar24.argaam.com/");


        new WebDriverWait(driver, Duration.ofSeconds(20)).until(ExpectedConditions.elementToBeClickable(By.id("akhbaarPolicyAccpetButton"))).click();
        new WebDriverWait(driver, Duration.ofSeconds(20)).until(ExpectedConditions.elementToBeClickable(By.id("LoginInfoDiv"))).click();
        Thread.sleep(3000);

//forget passward
        new WebDriverWait(driver, Duration.ofSeconds(20)).until(ExpectedConditions.elementToBeClickable(By.className("forgot-password"))).click();
        Thread.sleep(3000);
        //to perform Scroll on application using Selenium

        WebElement t = driver.findElement(By.xpath("//*[text()='البريد الإلكترونى']"));
// Javascript executor
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", t);
        Thread.sleep(3000);


        driver.findElement(By.id("userName")).sendKeys("sqa3@mailinator.com");
        Thread.sleep(3000);
        driver.findElement(By.id("submitButton")).click();
        Thread.sleep(3000);


//        //to perform Scroll on application using Selenium

       WebElement txt = driver.findElement(By.xpath("//*[text()='يرجى تفقد بريدك الالكتروني']"));
// Javascript executor
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", txt);
        Thread.sleep(3000);

//                ((JavascriptExecutor)driver).executeScript("window.open()");
//        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
//        driver.switchTo().window(tabs.get(1));
//        driver.get("https://www.mailinator.com/");
//               Thread.sleep(3000);
//        driver.findElement(By.id("search")).sendKeys("sqa3");
//        driver.findElement(By.xpath("//*[@id=\"site-header\"]/div[1]/div/div/div[1]/div/button")).click();
//        Thread.sleep(3000);
//       // driver.findElement(By.xpath("")).click();
//        driver.navigate().refresh();
//        Thread.sleep(3000);
//        driver.findElement(By.xpath("//*[@id=\"row_sqa3-1653909176-16831579\"]/td[2]")).click();


    }


   }



