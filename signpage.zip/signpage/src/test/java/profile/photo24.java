package profile;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriverException;

import static profile.class2.driver;

public class photo24 {
        public void photo() {
            class2.driver.navigate().to("https://akhbaar24.argaam.com/article/allgalleries/1");
            String actualTitle = class2.driver.getTitle();
            System.out.println(actualTitle);

            if (actualTitle.contentEquals("صور 24 - صفحة 1")){
                System.out.println("Test Passed!video24 page open");
            } else {
                System.out.println("Test Failed photo24 page not open");
            }
            System.out.println("photo24 page open");

            JavascriptExecutor js = (JavascriptExecutor) driver;
            try {
                Thread.sleep(3000);
                int i=0;
                for(;i<=2000;i++) {
                    ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0,1)"), "");
                }
                for(;i>0;i--) {
                    ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0,1)"), "");
                }
            } catch (WebDriverException wde) {
            } catch (Exception e) {
            }
            try {
                int j=0;
                for(;j>-300;j--) {
                    ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0,"+j+")"), "");
                }
                for(;j<0;j++) {
                    ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0,"+j+")"), "");
                }
            } catch (WebDriverException wde) {
            } catch (Exception e) {
            }



        }
    }

