package profile;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import static profile.class2.driver;

public class Weather {
    public void WeatherWidget(){
        try {
            Thread.sleep(1000);
            driver.findElement(By.xpath("//div//div[1]//a[2]//i[@class=\"arrow\"]")).click();
            Thread.sleep(3000);
            System.out.println("Weather Widget Open");
        } catch (Exception exp) {

            System.out.println("Weather widget arroq is not clickeable");
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }
        try {
            Thread.sleep(1000);
            Select se = new Select(driver.findElement(By.xpath("//*[@id='homePageCountriesDDL']")));
            se.selectByIndex(3);
            System.out.println("Country Changes");
            Thread.sleep(3000);
        }
        catch (Exception exp) {
            System.out.println("Country Not changes");
        }
        try {
            Thread.sleep(1000);
            Select me = new Select(driver.findElement(By.xpath("//*[@id='homePageCitiesDDL']")));
            Thread.sleep(1000);
            // Select the option by index
            me.selectByIndex(3);
            System.out.println("City changes");
            Thread.sleep(1000);
            System.out.println("Weather Changes");
        }
        catch (Exception exp) {
            System.out.println("Weather not changes");
        }
    }
}
