package profile;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Logout {
    public void signout()
    {

        new WebDriverWait(class2.driver, Duration.ofSeconds(20)).until(ExpectedConditions.elementToBeClickable(By.className("user-return"))).click();
    }

}
