package profile;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import java.time.Duration;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class intialtest {

    public void sigin() {
        //signin
        //case1
        try {
//            try {
//                Thread.sleep(3000);
//                class2.driver.findElement(By.id("btnLogin")).click();
//                String eemaile1 = "البريد الالكتروني ( مطلوب )";
//                String actualerrore1 = class2.driver.findElement(By.className("field-validation-error")).getText();
//                String epasse1 = "ادخل كلمة المرور.";
//                String actualerrorp1 = class2.driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div/form/fieldset[2]/span/span")).getText();
//
//
//                if (actualerrore1.equalsIgnoreCase(eemaile1) || actualerrorp1.equalsIgnoreCase(epasse1)) {
//                    System.out.println("Test Pass!enter id and password");
//                } else {
//                    System.out.println("Test Fail sign in without credentials");
//                }
//
//
////            String welcome= "مرحبا";
////        String wel = class2.driver.findElement(By.className("logged-user-name")).getText();
////        if (welcome.equalsIgnoreCase(wel)){
////            System.out.println("Test Passed!logged in failed");
////        } else {
////            System.out.println("Test Failed user login without credentials");
////        }
////
//
//
//            } catch (InterruptedException e) {
//                System.out.println("Test Case 1 skipped");
//            }
//
//
//            //case2
//            try {
//                Thread.sleep(3000);
//                WebElement email = class2.driver.findElement(By.id("UserName"));
//                String eemaile2 = "البريد الالكتروني غير صحيح.";
//                String[] variable = {"testAtgmail.com", "test@gmailcom", "test@gmail", "@gmail"};
//
//                for (int i = 0; i <= 3; i++) {
//
//                    email.sendKeys(variable[i]);
//
//                    System.out.println(variable[i]);
//
//                    class2.driver.findElement(By.id("btnLogin")).click();
//
//                    String actualerrore2 = class2.driver.findElement(By.className("field-validation-error")).getText();
//
//                    if (actualerrore2.equalsIgnoreCase(eemaile2)) {
//                        System.out.println("Test pass on invalid email format");
//                    } else {
//                        System.out.println("Test fail! on invalid email format");
//                    }
//
//                    Thread.sleep(3000);
//                    email.clear();
//                }
//
//            } catch (Exception e) {
//                System.out.println("Test Case 2 skipped");
//            }
//
//
//            //case3
//            try {
//
//                Thread.sleep(2000);
//                WebElement email = class2.driver.findElement(By.id("UserName"));
//                email.sendKeys("fpdanat@argaam.com");
//                Thread.sleep(2000);
//
//                class2.driver.findElement(By.id("btnLogin")).click();
//                String epasse1 = "ادخل كلمة المرور.";
//                String actualerrorp1 = class2.driver.findElement(By.xpath("/html/body/div[2]/div/div[1]/div[2]/div/form/fieldset[2]/span/span")).getText();
//
//
//                if (actualerrorp1.equalsIgnoreCase(epasse1)) {
//                    System.out.println("Test pass enter password");
//                } else {
//                    System.out.println("Test fail!sign in without password");
//                }
//            } catch (Exception e) {
//                System.out.println("Test Case 3 skipped");
//            }
//
////case4
//            try {
//                Thread.sleep(3000);
//                WebElement email = class2.driver.findElement(By.id("UserName"));
//                email.clear();
//                WebElement password = class2.driver.findElement(By.id("Password"));
//                password.sendKeys("arg@@md@n@t321$$");
//                Thread.sleep(1000);
//                class2.driver.findElement(By.id("btnLogin")).click();
//
//                String eemaile1 = "البريد الالكتروني ( مطلوب )";
//                String actualerrore1 = class2.driver.findElement(By.className("field-validation-error")).getText();
//
//                if (actualerrore1.equalsIgnoreCase(eemaile1)) {
//                    System.out.println("Test pass enter email");
//                } else {
//                    System.out.println("Test fail!sign in without email");
//                }
//                password.clear();
//
//            } catch (Exception e) {
//                System.out.println("Test Case 4 skipped");
//            }
//
//
//            //case5
//            try {
//                Thread.sleep(3000);
//                WebElement email = class2.driver.findElement(By.id("UserName"));
//                email.clear();
//                WebElement password = class2.driver.findElement(By.id("Password"));
//                password.clear();
//
//                email.sendKeys("fpdanat@argaam.com");
//                password.sendKeys("arg@@mdt321$$");
//                class2.driver.findElement(By.id("btnLogin")).click();
//
//                String expectederror3 = "لا يمكنك الدخول، الرجاء التأكد من كتابة الايميل والباسورد بشكل صحيح";
//                String actualerror3 = class2.driver.findElement(By.id("LoginError")).getText();
//
//
//                if (actualerror3.equalsIgnoreCase(expectederror3)) {
//                    System.out.println("Test pass!credentials invalid");
//                } else {
//                    System.out.println("Test fail on credentials invalid");
//                }
//
//            } catch (Exception e) {
//                System.out.println("Test Case 5 skipped");
//            }


// true case username and password Insertion
            try
            {
            Thread.sleep(3000);
            WebElement email = class2.driver.findElement(By.id("UserName"));
            email.clear();
            WebElement password = class2.driver.findElement(By.id("Password"));
            password.clear();
            email.sendKeys("sqa3@mailinator.com");
            password.sendKeys("Aqsa123?");
            class2.driver.findElement(By.id("RememberMe")).click();

            class2.driver.findElement(By.id("btnLogin")).click();
            Thread.sleep(2000);

        String wel = new WebDriverWait(class2.driver, Duration.ofSeconds(20)).until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[5]/div[2]/div[2]/div[1]/div[2]/span[3]"))).getText();
        System.out.println(wel);

        if (wel.contentEquals("مرحبا,")){

            System.out.println("Test Passed!logged in");
        } else {
            System.out.println("Test Failed user could not login");
        }
            Thread.sleep(1000);

        } catch (InterruptedException e) {
            System.out.println("true test case for sigin skip ");
        }


        } catch (Exception e) {

            System.out.println("Sign in skipped");
        }

    }


            public void profileedit () {

                // profile
                try {
                    new WebDriverWait(class2.driver, Duration.ofSeconds(20)).until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"LoggedInUserNameSpan\"]/a"))).click();
                   // Thread.sleep(1000);

                    // String expectedTitle = "اخبار 24 | التسجيل ";
                    // get the actual value of the title
                    String actualTitle = class2.driver.getTitle();
                    System.out.println(actualTitle);

                    if (actualTitle.contentEquals("اخبار 24 | التسجيل")){
                        System.out.println("Test Passed!profile page tittle matched");
                    } else {
                        System.out.println("Test Failed profile page tittle didn't matched");
                    }

                    Thread.sleep(3000);
//to perform Scroll on application using Selenium
                JavascriptExecutor js = (JavascriptExecutor) class2.driver;
// identify element
                WebElement text = class2.driver.findElement(By.xpath("//*[text()='تحديث الملف الشخصي']"));
// Javascript executor
                ((JavascriptExecutor) class2.driver).executeScript("arguments[0].scrollIntoView(true);", text);



                //case1
                    try {

                      // String expectedvalue = " sqa3@mailinator.com";
                        class2.driver.findElement(By.id("email")).clear();
                        class2.driver.findElement(By.id("email")).sendKeys("sqa2@mailinator.com");
                      String value = class2.driver.findElement(By.id("email")).getText();

                      System.out.println(value);

//                      if (value.contentEquals("sqa3@mailinator.com" )) {
//                            System.out.println("Test Pass!email not edited");
//                        } else {
//                            System.out.println("Test fail email not edited");
//                        }


                    } catch (Exception e) {
                        System.out.println("Test Case 1 skipped (profile)");
                    }



//Case2
//clear fields
                    try {

               WebElement dname = class2.driver.findElement(By.id("display_name"));
               dname.clear();
                class2.driver.findElement(By.id("first_name")).clear();
                class2.driver.findElement(By.id("last_name")).clear();
                Thread.sleep(2000);

                dname.sendKeys("checkinga24");
                class2.driver.findElement(By.id("submitBtn")).click();


                        //   String expectederror = "اسم العرض هو المطلوب.";
                String actualdname = class2.driver.findElement(By.xpath("/html/body/div[5]/div[2]/div[1]/div[1]/div[2]/span[4]/a")).getText();
                String Message = class2.driver.findElement(By.xpath("/html/body/div[5]/div[4]/div/div[1]/div[1]/div[2]/div/div[2]/div/table/tbody/tr/td")).getText();
                if (actualdname.contentEquals("checkinga24")&& Message.contentEquals("تم تعديل الملف الشخصى بنجاح")) {
                            System.out.println("Test pass on non required field empty");
                        } else {
                            System.out.println("Test fail on non required field empty");
                        }

                    } catch (Exception e) {
                        System.out.println("Test Case 2 skipped (profile)");
                    }



//case2

//                    try {
//
//                        class2.driver.findElement(By.id("display_name")).clear();
//                        class2.driver.findElement(By.id("first_name")).clear();
//                        class2.driver.findElement(By.id("last_name")).clear();
//                        Thread.sleep(2000);
//                        class2.driver.findElement(By.id("submitBtn")).click();
//                        Thread.sleep(1000);
//                        class2.driver.findElement(By.xpath("")).getText();
//                        String tittle = class2.driver.getTitle();
//                        System.out.println(actualTitle);
//
//                        if (tittle.contentEquals("اخبار 24 | تمت عملية التسجيل بنجاح ")){
//                            System.out.println("Test Passed!profile page tittle matched");
//                        } else {
//                            System.out.println("Test Failed profile page tittle didn't matched");
//                        }

//
//                    } catch (Exception e) {
//                        System.out.println("Test Case 1 skipped (profile)");
//                    }


////add fields
//                class2.driver.findElement(By.id("display_name")).sendKeys("gvgc");
//                Thread.sleep(1000);
//
//                class2.driver.findElement(By.id("first_name")).sendKeys("hvhv");
//                Thread.sleep(1000);
//
//                class2.driver.findElement(By.id("last_name")).sendKeys("hhh");
//                Thread.sleep(1000);
//
//
//                class2.driver.findElement(By.id("submitBtn")).click();
//
//                //to perform Scroll on application using Selenium
//                JavascriptExecutor jss = (JavascriptExecutor) class2.driver;
//// identify element
//                WebElement text2 = class2.driver.findElement(By.xpath("/html/body/div[5]/div[4]/div/div[2]/div[3]/div[2]/div/div[2]/h2"));
//// Javascript executor
//                ((JavascriptExecutor) class2.driver).executeScript("arguments[0].scrollIntoView(true);", text2);
//                try {
//                    Thread.sleep(2000);
//                } catch (InterruptedException e) {
//                    System.out.println(e);
//                }
//                new WebDriverWait(class2.driver, Duration.ofSeconds(20)).until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[5]/div[3]/ul/li[1]/a"))).click();
//
                }


                catch (InterruptedException e) {
                    System.out.println("profile edit skipped");
                }
            }





            public void signout () {
        try{

                new WebDriverWait(class2.driver, Duration.ofSeconds(20)).until(ExpectedConditions.elementToBeClickable(By.className("user-return"))).click();
            } catch (Exception e) {
        System.out.println("Signout skipped");
    }


            }
    }
