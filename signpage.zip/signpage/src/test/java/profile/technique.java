package profile;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriverException;

import static profile.class2.driver;

public class technique {
    public void techniques24() {
try {
        class2.driver.navigate().to("https://akhbaar24.argaam.com/article/list/117/%d8%aa%d9%82%d9%86%d9%8a%d8%a9/1?utm_source=internal&utm_medium=desktop-menu&utm_campaign=section&utm_term=technology");
    String actualTitle = class2.driver.getTitle();
    System.out.println(actualTitle);

    if (actualTitle.contentEquals("تقنية - صفحة 1")){
        System.out.println("Test Passed!video24 page open");
    } else {
        System.out.println("Test Failed technique page not open");
    }
    System.out.println("technique page open");
        JavascriptExecutor js = (JavascriptExecutor) driver;
        try {
            Thread.sleep(3000);
            int i = 0;
            for (; i <= 2000; i++) {
                ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0,1)"), "");
            }
            for (; i > 0; i--) {
                ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0,1)"), "");
            }
        } catch (WebDriverException wde) {
        } catch (Exception e) {
        }
        try {
            int j = 0;
            for (; j > -300; j--) {
                ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0," + j + ")"), "");
            }
            for (; j < 0; j++) {
                ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0," + j + ")"), "");
            }
        } catch (WebDriverException wde) {
        } catch (Exception e) {
        }
    }catch (Exception exp){
        System.out.printf("techniques24 page doesnt open");

    }

    }
}
