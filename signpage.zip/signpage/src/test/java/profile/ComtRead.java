package profile;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import static profile.class2.driver;

public class ComtRead {
    public void readCmt(){
        try {
            Thread.sleep(2000);
            WebElement n = driver.findElement(By.xpath("//*[text()='الاكثر تعليقاً']"));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", n);
            System.out.println("Text Matches");
        }catch (Exception exp) {
            System.out.println("Text not Matches");
        }
        try {
            Thread.sleep(2000);
            driver.findElement(By.xpath(" //*[@id=\"mostCommentedTab_tabbedArticleList\"]")).click();
            System.out.println("Tab Switches");
            Thread.sleep(3000);
        }
        catch (Exception exp) {
            System.out.println("Tab Not Switces Matches");
        }
        try {
            Thread.sleep(2000);
            driver.findElement(By.xpath(" //*[@id=\"mostReadTab_tabbedArticleList\"]")).click();
            System.out.println("Tab Switches");
            Thread.sleep(3000);
        }
        catch (Exception exp) {
            System.out.println("Tab Not Switces Matches");
        }



    }


}
