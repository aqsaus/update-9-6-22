package profile;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;

import static profile.class2.driver;

public class video24 {
    public void video() {
        try{
       class2.driver.navigate().to("https://akhbaar24.argaam.com/video24/1");
       String actualTitle = class2.driver.getTitle();
       System.out.println(actualTitle);

            if (actualTitle.contentEquals("افيديو 24 : شاهد الفيديوهات الاكثر انتشاراً - صفحة 1")){
                System.out.println("Test Passed!video24 page open");
            } else {
                System.out.println("Test Failed video24 page not open");
            }
            System.out.println("video24 page open");

        JavascriptExecutor js = (JavascriptExecutor) driver;
        try {
            Thread.sleep(3000);
            int i=0;
            for(;i<=1000;i++) {
                ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0,1)"), "");
            }
            for(;i>0;i--) {
                ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0,1)"), "");
            }
        } catch (WebDriverException wde) {
        } catch (Exception e) {
        }
        try {
            int j=0;
            for(;j>-300;j--) {
                ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0,"+j+")"), "");
            }
            for(;j<0;j++) {
                ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0,"+j+")"), "");
            }
        } catch (WebDriverException wde) {
        } catch (Exception e) {
        }
    }catch (Exception exp){
        System.out.printf("video24 page doesnt open");

    }



        }
    }



