package profile;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import static profile.class2.driver;

public class ArticleDetail {

    public void articleopen(){
        JavascriptExecutor js = (JavascriptExecutor) driver;
        try {
            Thread.sleep(2000);
            driver.findElement(By.xpath("//*[@id=\"content\"]/div[1]/div[1]/h2/a")).click();
            System.out.println("Article Detail opens");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            Thread.sleep(3000);
            //driver.get("https://akhbaar24.argaam.com/");
            driver.navigate().back();
            Thread.sleep(1000);
        }
        catch (Exception exp) {
            System.out.println("Link not Open");
        }
    }

}
