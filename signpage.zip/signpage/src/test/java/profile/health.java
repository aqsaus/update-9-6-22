package profile;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriverException;

import static profile.class2.driver;

public class health {
    public void health24() {
        try{
        class2.driver.navigate().to("https://akhbaar24.argaam.com/article/list/116/%d8%b5%d8%ad%d8%a9/1?utm_source=internal&utm_medium=desktop-menu&utm_campaign=section&utm_term=health");

        String actualTitle = class2.driver.getTitle();
            System.out.println(actualTitle);

            if (actualTitle.contentEquals("صحة - صفحة 1")){
                System.out.println("Test Passed!health24 page open");
            } else {
                System.out.println("Test Failed health page not open");
            }
            System.out.println("technique page open");
        JavascriptExecutor js = (JavascriptExecutor) driver;
        try {
            Thread.sleep(3000);
            int i = 0;
            for (; i <= 2000; i++) {
                ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0,1)"), "");
            }
            for (; i > 0; i--) {
                ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0,1)"), "");
            }
        } catch (WebDriverException wde) {
        } catch (Exception e) {
        }
        try {
            int j = 0;
            for (; j > -300; j--) {
                ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0," + j + ")"), "");
            }
            for (; j < 0; j++) {
                ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0," + j + ")"), "");
            }
        } catch (WebDriverException wde) {
        } catch (Exception e) {
        }
    }catch (Exception exp){
        System.out.printf("health page doesnt open");

    }

    }
}
