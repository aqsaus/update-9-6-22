package profile;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import static profile.class2.driver;

public class sport24 {

    public void sport() {
        driver.get("https://akhbaar24.argaam.com/sports");

        JavascriptExecutor js = (JavascriptExecutor) driver;
        try {
            Thread.sleep(3000);
            WebElement l = driver.findElement(By.xpath("//*[text()='المباريات']"));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", l);
        } catch (Exception exp) {
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }
        try {
            driver.findElement(By.xpath("//*[@id=\"futureMatchList\"]")).click();
            Thread.sleep(2000);
        } catch (Exception exp) {
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }
        try {
            driver.findElement(By.xpath("//*[@id=\"pastMatchList\"]")).click();
            Thread.sleep(2000);
        } catch (Exception exp) {
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }
        try {
            driver.findElement(By.xpath("//*[@id=\"todaysMatchList\"]")).click();
            Thread.sleep(2000);
        } catch (Exception exp) {
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }
        try {
            WebElement d = driver.findElement(By.xpath("//*[text()='الترتيب']"));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", d);
        } catch (Exception exp) {
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }
        try {
            driver.findElement(By.xpath("//*[@id=\"384\"]")).click();
            Thread.sleep(2000);
        } catch (Exception exp) {
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }
        try {
            driver.findElement(By.xpath("//*[@id=\"374\"]")).click();
            Thread.sleep(2000);
        } catch (Exception exp) {
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }
        try {
            driver.findElement(By.xpath("//*[@id=\"397\"]")).click();
            Thread.sleep(2000);
        } catch (Exception exp) {
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }
        try {
            driver.findElement(By.xpath("//*[@id=\"394\"]")).click();
            Thread.sleep(2000);
        } catch (Exception exp) {
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }
        try {
            driver.findElement(By.xpath("//*[@id=\"396\"]")).click();
            Thread.sleep(2000);
        } catch (Exception exp) {
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }
        try {
            driver.findElement(By.xpath("//*[@id=\"381\"]")).click();
            Thread.sleep(2000);
        } catch (Exception exp) {
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }
        try {
        js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
        Thread.sleep(2000);
        js.executeScript("window.scrollBy(0,-document.body.scrollHeight)");
        } catch (Exception exp) {
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }
        try {
            Thread.sleep(2000);
            driver.findElement(By.xpath("//a[@href='/sports#standingsdiv']")).click();
            System.out.println("Opening Tartibul Farq");
            Thread.sleep(3000);
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            driver.navigate().back();
            Thread.sleep(2000);
        } catch (Exception exp) {
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }
        try {
            Thread.sleep(2000);
            driver.findElement(By.xpath("//*[@id=\"hottopics\"]/li[3]/a")).click();
            System.out.println("Opening Nadi Al Nasr");
            Thread.sleep(3000);
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
//            Thread.sleep(7000);
//            driver.navigate().back();
            Thread.sleep(2000);
        } catch (Exception exp) {
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }
        try {
            Thread.sleep(2000);
            driver.findElement(By.xpath("//*[@id=\"hottopics\"]/li[4]/a")).click();
            System.out.println("Opening NAdi Halal");
            Thread.sleep(3000);
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
//            Thread.sleep(7000);
//            driver.navigate().back();
            Thread.sleep(2000);
        } catch (Exception exp) {
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }


        try {
            Thread.sleep(2000);
            driver.findElement(By.xpath("//*[@id=\"hottopics\"]/li[5]/a")).click();
            System.out.println("Opening NAdi Itehaad");
            Thread.sleep(3000);
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
//            Thread.sleep(7000);
//            driver.navigate().back();
            Thread.sleep(2000);
        } catch (Exception exp) {
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }
        try {
            Thread.sleep(2000);
            driver.findElement(By.xpath("//*[@id=\"hottopics\"]/li[6]/a")).click();
            System.out.println("Opening NAdi Zahli");
            Thread.sleep(3000);
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
//            Thread.sleep(7000);
//            driver.navigate().back();
            Thread.sleep(2000);
        } catch (Exception exp) {
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }
        try {
            Thread.sleep(3000);
            driver.findElement(By.xpath("//*[@id=\"hottopics\"]/li[7]/a")).click();
            System.out.println("Opening NAdi Al shabab");
            Thread.sleep(3000);
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
            js.executeScript("window.scrollBy(0,150)", "");
//            Thread.sleep(7000);
//            driver.navigate().back();
            Thread.sleep(2000);
        } catch (Exception exp) {
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }

        try {
            Thread.sleep(2000);
            driver.findElement(By.xpath("//*[@id=\"hottopics\"]/li[8]/a")).click();
            System.out.println("Opening Akhbar24");
            Thread.sleep(7000);
//            Thread.sleep(7000);
//            driver.navigate().back();
            Thread.sleep(2000);
        } catch (Exception exp) {
            System.out.println(exp.getCause());
            System.out.println(exp.getMessage());
            exp.printStackTrace();
        }
    }

}
