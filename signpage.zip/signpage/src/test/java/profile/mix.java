package profile;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriverException;

import static profile.class2.driver;

public class mix {
    public void mix24() {
        try
        {
        class2.driver.navigate().to("https://akhbaar24.argaam.com/article/list/104/%d9%85%d9%86%d9%88%d8%b9%d8%a7%d8%aa/1");
            String actualTitle = class2.driver.getTitle();
            System.out.println(actualTitle);

            if (actualTitle.contentEquals("منوعات - صفحة 1")){
                System.out.println("Test Passed!video24 page open");
            } else {
                System.out.println("Test Failed mix page not open");
            }
            System.out.println("mix page open");

        JavascriptExecutor js = (JavascriptExecutor) driver;
        try {
            Thread.sleep(3000);
            int i=0;
            for(;i<=2000;i++) {
                ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0,1)"), "");
            }
            for(;i>0;i--) {
                ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0,1)"), "");
            }
        } catch (WebDriverException wde) {
        } catch (Exception e) {
        }
        try {
            int j=0;
            for(;j>-300;j--) {
                ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0,"+j+")"), "");
            }
            for(;j<0;j++) {
                ((JavascriptExecutor) driver).executeScript(("window.scrollBy(0,"+j+")"), "");
            }
        } catch (WebDriverException wde) {
        } catch (Exception e) {
        }
    }catch (Exception exp){
        System.out.printf("mix page doesnt open");

    }



    }
}
